<?php
// Location: ./application/libraries/Pdf.php / 
if ( ! defined('BASEPATH'))

 exit('No direct script access allowed');
 // require_once dirname(FILE) . '/tcpdf/tcpdf.php';
     require APPPATH . '/libraries/tcpdf/tcpdf.php';
defined('BASEPATH') OR exit('No direct script access allowed');

class Pdf extends TCPDF {
public function Header(){
	$ImageFile=K_PATH_IMAGES.'logo_example.jpg';
	$this->Image($ImageFile,20,10,20, '', 'JPG','','T', false,300,'',false,false,0,false,false,false);
	$this->Ln(5);// font name size style
	$this->setFont('helvetica','B',12);
	//189 total width of A4 page, height, border, line
	$this->Cell(189,5,'Biltz Security Services',0,1,'C');
	$this->setFont('helvetica','',8);
	$this->Cell(189,3,'PRIVATE LIMITED',0,1,'C');
	$this->Cell(189,3,'20E, Mezzanine Floor, Lane 12, Phase II extension DHA Karachi.',0,1,'C');
	$this->Cell(189,3,'Tel: Head Office: 021-35803850-51 Fax: 021-35803852',0,1,'C');
	$this->Cell(189,3,'Tel: Operations: 021-35899118 Email: Info@bilzsecurity.com.pk',0,1,'C');
	$this->Cell(189,3,'URL: www.biltzsecurity.com.pk',0,1,'C');

}
public function Footer(){
	$this->setY(-70); //position at 15mm from bottom
	$this->Ln(2);
	$this->setFont('times','B',10);

// 	$this->Cell(20, 1, '',0,0);
// 	$this->Cell(118, 1, '',0,0);
// 	$this->Cell(51, 1, '',0,1); 
// 	$this->Cell(20, 5, 'Department Officer',0,0); 

// 	$this->Cell(118, 5, '',0,0);
// 	$this->Cell(51, 5, 'Stamp',0,1);
	
	
	$this->Cell(20, 1, 'Department Officer',0,0);
	$this->Cell(118, 1, '',0,0);
	$this->Cell(51, 1, '',0,1); 
	$this->Cell(20, 5, 'Biltz Security Services (Pvt) Ltd',0,0); 
	$this->Cell(118, 5, '',0,0);
	$this->Cell(51, 5, 'Stamp',0,1);
	
		$this->Ln(5);
		$this->Cell(200,3,'- - - - - - - - -  - - - - - - - - - - - - - - - - - - - - - - - - - - - - ',0,1,'C');
	$this->Ln(40);
	//set font
	 $this->setFont('helvetica','I',8);
	 //pagenumber
	 	// $today= date('F j, Y/ g:i A',time());

$date = new DateTime('', new DateTimeZone('America/New_York'));
$date->format('Y-m-d h:i A') . "\n";

$date->setTimezone(new DateTimeZone('Asia/Karachi'));
$today= $date->format('F j, Y/h:i A') . "\n";
	 	$this->Cell(25, 5, 'Generated Date/Time: '.$today,0,0,'L');
	 	$this->Cell(164, 5, 'Page'.$this->getAliasNumPage().'of'.$this->getAliasNbpages(),0,false,'R',0,'',0,false,'T','M');

	
}
}
 ?>